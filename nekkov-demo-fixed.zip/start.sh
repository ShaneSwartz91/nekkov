
#!/usr/bin/env bash
set -euo pipefail

# Start API
python -m uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 &

# Build frontend if not already built
if [ ! -d "/app/frontend/dist" ]; then
  cd /app/frontend && npm ci || npm i && npm run build
fi

# Start Caddy to serve frontend and proxy /api
exec caddy run --config /app/Caddyfile --adapter caddyfile
