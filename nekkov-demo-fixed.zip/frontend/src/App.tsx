
import React, { useEffect, useState } from 'react'

const API = '/api'

export default function App() {
  const [kpis, setKpis] = useState<any>(null)
  const [msg, setMsg] = useState('')
  useEffect(() => {
    fetch(API + '/health').then(r => r.json()).catch(()=>{})
    fetch(API + '/demo/kpis').then(r => r.json()).then(setKpis).catch(() => {})
  }, [])

  return (
    <div style={{background:'#0b1220', color:'#e6f0ff', minHeight:'100vh', fontFamily:'Inter, system-ui, sans-serif'}}>
      <header style={{padding:'16px 24px', display:'flex', justifyContent:'space-between', alignItems:'center', borderBottom:'1px solid #1f2a44'}}>
        <div style={{fontWeight:700}}>Nekkov Logistics • Demo</div>
        <div style={{opacity:.8}}>Namibia Business Software</div>
      </header>

      <main style={{padding:'24px', maxWidth:1000, margin:'0 auto'}}>
        <h1 style={{fontSize:28, marginBottom:8}}>ERP Dashboard (Demo)</h1>
        <p style={{opacity:.8, marginBottom:16}}>Dark, futuristic look with blue accents. Ask the AI Help bot how to upload an invoice.</p>

        <section style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:16}}>
          <Kpi title="Shipments in Transit" value={kpis?.shipments_in_transit ?? '—'} />
          <Kpi title="On-time Rate" value={kpis ? (kpis.on_time_rate*100).toFixed(1)+'%' : '—'} />
          <Kpi title="AP Invoices in Review" value={kpis?.ap_invoices_review ?? '—'} />
          <Kpi title="AR Outstanding" value={kpis ? 'N$ ' + kpis.ar_outstanding.toLocaleString() : '—'} />
        </section>

        <section style={{marginTop:24, background:'#0f1a33', border:'1px solid #1f2a44', borderRadius:12, padding:16}}>
          <h2 style={{marginTop:0}}>Upload Supplier Invoice (Mock AI capture)</h2>
          <form onSubmit={async e => {
            e.preventDefault()
            const input = (document.getElementById('f') as HTMLInputElement)
            if (!input.files?.length) { setMsg('Choose a file first'); return }
            const fd = new FormData()
            fd.append('file', input.files[0])
            const r = await fetch(API + '/ap/invoices/upload', { method:'POST', body:fd })
            const j = await r.json()
            setMsg('Extracted: ' + JSON.stringify(j.extracted, null, 2))
          }}>
            <input id="f" type="file" accept=".pdf,.png,.jpg,.jpeg" />
            <button style={{marginLeft:12, padding:'6px 12px', background:'#1f5eff', border:'none', color:'white', borderRadius:6}}>Upload</button>
          </form>
          {msg && <pre style={{whiteSpace:'pre-wrap', marginTop:12, background:'#0b1429', padding:12, borderRadius:8}}>{msg}</pre>}
        </section>

        <section style={{marginTop:24, display:'grid', gridTemplateColumns:'1fr 1fr', gap:16}}>
          <Card title="Customer Portal" text="View invoices, statements, and messages." />
          <Card title="Supplier Portal" text="Upload invoices, view POs, and chat with AP." />
          <Card title="EDI Samples" text="Browse sample 810/850 and replay into the system." />
          <Card title="AI Help" text="Click the floating bot for 'how do I' answers." />
        </section>
      </main>

      <HelpBot />
    </div>
  )
}

function Kpi({title, value}:{title:string, value:any}){
  return (
    <div style={{background:'#0f1a33', border:'1px solid #1f2a44', borderRadius:12, padding:16}}>
      <div style={{opacity:.8, fontSize:12}}>{title}</div>
      <div style={{fontSize:22, fontWeight:700}}>{value}</div>
    </div>
  )
}

function Card({title, text}:{title:string, text:string}){
  return (
    <div style={{background:'#0f1a33', border:'1px solid #1f2a44', borderRadius:12, padding:16}}>
      <div style={{fontWeight:600, marginBottom:6}}>{title}</div>
      <div style={{opacity:.85}}>{text}</div>
    </div>
  )
}

function HelpBot(){
  const [open, setOpen] = React.useState(false)
  const [answer, setAnswer] = React.useState<string>('')
  const ask = async (q:string) => {
    if (q.toLowerCase().includes('upload')) setAnswer('Go to the dashboard and use "Upload Supplier Invoice".')
    else setAnswer('Try: "How do I upload an invoice?" or "Where is EDI?"')
  }
  return (
    <div>
      {open && (
        <div style={{position:'fixed', bottom:84, right:24, width:320, background:'#0f1a33', border:'1px solid #1f2a44', borderRadius:12, padding:12}}>
          <div style={{fontWeight:600, marginBottom:8}}>AI Help</div>
          <input placeholder="Ask how to..." onKeyDown={e=>{ if(e.key==='Enter') ask((e.target as HTMLInputElement).value) }}
            style={{width:'100%', padding:'8px', borderRadius:8, border:'1px solid #1f2a44', background:'#0b1429', color:'#e6f0ff'}}/>
          <div style={{marginTop:8, opacity:.9}}>{answer}</div>
        </div>
      )}
      <button onClick={()=>setOpen(!open)} style={{position:'fixed', bottom:24, right:24, background:'#1f5eff', border:'none', color:'white', borderRadius:999, padding:'12px 16px'}}>
        {open ? 'Close Help' : 'Help'}
      </button>
    </div>
  )
}
