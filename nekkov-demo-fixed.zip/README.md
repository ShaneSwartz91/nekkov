
# Nekkov Logistics Demo (Railway-ready)

Single Docker service (FastAPI API + React frontend + Caddy reverse proxy).

## Run locally
```bash
docker build -t nekkov-demo .
docker run -p 8080:8080 nekkov-demo
# open http://localhost:8080
```

## Deploy to Railway
**Option A – GitHub connect**
1) Push this folder to a GitHub repo.
2) In Railway: New Project → GitHub Repo → select your repo.
3) Railway builds the Dockerfile automatically.
4) Project → Settings → Domains → Add `nekkov.namibia-software.com` (CNAME to the Railway target).

**Option B – Railway CLI (no GitHub)**
```bash
npm i -g @railway/cli
railway login
railway init    # create/select a project
railway up      # deploy from this folder
```

## Endpoints
- Web UI: `/`
- API: `/api/*` → `/api/health`, `/api/demo/kpis`, `/api/ap/invoices/upload`

Demo is self-contained (no database required).
