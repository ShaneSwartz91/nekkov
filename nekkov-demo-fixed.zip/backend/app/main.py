from fastapi import FastAPI, UploadFile, File, Query
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Nekkov Logistics Demo API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.get("/api/demo/kpis")
def demo_kpis():
    return {
        "revenue": 125000,
        "shipments_today": 42,
        "on_time_rate": 0.97,
        "open_invoices": 7
    }

@app.post("/api/invoice/extract")
async def invoice_extract(file: UploadFile = File(...)):
    # Mocked AI extraction
    _ = await file.read()
    extracted = {
        "vendor": "Sample Supplier (Pty) Ltd",
        "invoice_number": "INV-1001",
        "invoice_date": "2025-08-01",
        "currency": "NAD",
        "total": 12450.75,
        "lines": [
            {"sku": "PALLET", "desc": "Warehouse Pallet Handling", "qty": 10, "price": 250.0},
            {"sku": "ROUTE-NA-01", "desc": "Transport Walvis Bay → Windhoek", "qty": 1, "price": 9950.75}
        ]
    }
    return {"status": "draft", "extracted": extracted}

@app.get("/api/ai/help")
def ai_help(q: str = Query("", description="Help prompt")):
    # Tiny mocked nav helper
    answers = {
        "invoice": "To capture an invoice, drag-and-drop the PDF into the Invoice panel.",
        "edi": "EDI samples appear under Operations → EDI. Use the 'Simulate Flow' button.",
        "portal": "Customer/Supplier portals are accessible from the left nav under Portals."
    }
    for key, val in answers.items():
        if key in q.lower():
            return {"answer": val}
    return {"answer": "Try: 'invoice', 'EDI', or 'portal' for guided help."}
